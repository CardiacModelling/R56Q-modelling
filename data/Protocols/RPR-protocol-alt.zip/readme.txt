Myokit DataLog Binary File
--------------------------
This zip file contains binary time series data for one or multiple variables.
The file structure.txt contains structural information about the data in plain
text. The first line lists the number of fields. The second line gives the
length of the data arrays. The third line specifies the data type, either
single ("f") or double ("d") precision. The fourth line indicates which entry
corresponds to a time variable, or is blank if no time variable was explicitly
specified. Each following line contains the name of a data field, in the order
its data occurs in the binary data file "data.bin". All data is stored
little-endian.